-----------------------------------------------------------------------------------------------
HOW TO INSTALL:

 - Drag "/gm9/" Folder to the Root of your SD Card & Merge it(if there is already a gm9 folder)

------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------
PLEASE READ:

Inside of [0:/gm9/out/BanLFCS] is my "Banned LocalFriendCodeSeed_B"

  - Inject my Banned Friend Code into your 3DS, to keep your Unbanned Code Safe

     - This will Let you Run CIA's without getting your LFCS Banned!

        - Use in Combination with Incognito Mode Scripts

-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
HOW TO USE: 

1) Hold Start While Turning on your System to Load GodMode9
        - Press The Home Button 
               - Select "Scripts..." from the Menu

---------------------------------------------
*Optional First Time Step*: (DO THIS IF YOU HAVE AN UNBANNED 3DS!)
1.5) Run: "Extract Unbanned LFCS_B" Script
    - This will Backup your Unbanned LFCS_B [0:/gm9/out/UnLFCS] & Keep it Safe
---------------------------------------------

2) Run: "Inject Banned LFCS_B" Script
    - This will Inject my Banned Code into your 3DS & Keep your other from getting Banned!


3) Run: "Enable Incognito Mode Script"
    - This will keep your activity log from logging CIAs you Run

-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
HOW TO DISABLE & PLAY GAMES ONLINE AGAIN:

1) Run "Inject Unbanned LFCS_B" Script 
2) Run "Disable Incognito Mode" Script
 